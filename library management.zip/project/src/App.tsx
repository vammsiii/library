import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import BookManagement from './components/BookManagement';
import StudentManagement from './components/StudentManagement';
import IssueReturn from './components/IssueReturn';
import Reports from './components/Reports';
import Login from './components/Login';

export interface Book {
  book_id: number;
  title: string;
  author: string;
  publisher: string;
  year_published: number;
  isbn: string;
  copies_total: number;
  copies_avail: number;
  category: string;
}

export interface Student {
  student_id: number;
  name: string;
  email: string;
  course: string;
  year: number;
  phone: string;
  address: string;
}

export interface IssueLog {
  issue_id: number;
  book_id: number;
  student_id: number;
  book_title: string;
  student_name: string;
  issue_date: string;
  due_date: string;
  return_date?: string;
  status: 'issued' | 'returned' | 'overdue';
  fine_amount?: number;
}

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [books, setBooks] = useState<Book[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [issueLogs, setIssueLogs] = useState<IssueLog[]>([]);

  useEffect(() => {
    // Check if user is already logged in
    const authStatus = localStorage.getItem('isAuthenticated');
    if (authStatus === 'true') {
      setIsAuthenticated(true);
      initializeData();
    }
  }, []);

  const initializeData = () => {
    // Initialize with comprehensive programming and CS books
    const sampleBooks: Book[] = [
      // Programming Languages
      {
        book_id: 1,
        title: 'The C Programming Language',
        author: 'Brian W. Kernighan, Dennis M. Ritchie',
        publisher: 'Prentice Hall',
        year_published: 1988,
        isbn: '978-0131103627',
        copies_total: 8,
        copies_avail: 5,
        category: 'Programming'
      },
      {
        book_id: 2,
        title: 'C++ Primer',
        author: 'Stanley B. Lippman, Josée Lajoie',
        publisher: 'Addison-Wesley',
        year_published: 2012,
        isbn: '978-0321714114',
        copies_total: 6,
        copies_avail: 3,
        category: 'Programming'
      },
      {
        book_id: 3,
        title: 'Python Crash Course',
        author: 'Eric Matthes',
        publisher: 'No Starch Press',
        year_published: 2019,
        isbn: '978-1593279288',
        copies_total: 10,
        copies_avail: 7,
        category: 'Programming'
      },
      {
        book_id: 4,
        title: 'Effective Java',
        author: 'Joshua Bloch',
        publisher: 'Addison-Wesley',
        year_published: 2018,
        isbn: '978-0134685991',
        copies_total: 7,
        copies_avail: 4,
        category: 'Programming'
      },
      {
        book_id: 5,
        title: 'HTML and CSS: Design and Build Websites',
        author: 'Jon Duckett',
        publisher: 'Wiley',
        year_published: 2011,
        isbn: '978-1118008188',
        copies_total: 5,
        copies_avail: 2,
        category: 'Web Development'
      },
      {
        book_id: 6,
        title: 'JavaScript: The Definitive Guide',
        author: 'David Flanagan',
        publisher: "O'Reilly Media",
        year_published: 2020,
        isbn: '978-1491952023',
        copies_total: 8,
        copies_avail: 5,
        category: 'Web Development'
      },
      {
        book_id: 7,
        title: 'Learning Web Design',
        author: 'Jennifer Niederst Robbins',
        publisher: "O'Reilly Media",
        year_published: 2018,
        isbn: '978-1491960202',
        copies_total: 4,
        copies_avail: 2,
        category: 'Web Development'
      },
      // Computer Science Core Subjects
      {
        book_id: 8,
        title: 'Operating System Concepts',
        author: 'Abraham Silberschatz, Peter Galvin',
        publisher: 'Wiley',
        year_published: 2018,
        isbn: '978-1118063330',
        copies_total: 12,
        copies_avail: 8,
        category: 'Operating Systems'
      },
      {
        book_id: 9,
        title: 'Database System Concepts',
        author: 'Abraham Silberschatz, Henry Korth',
        publisher: 'McGraw-Hill',
        year_published: 2019,
        isbn: '978-0078022159',
        copies_total: 10,
        copies_avail: 6,
        category: 'Database Management'
      },
      {
        book_id: 10,
        title: 'Computer Networks',
        author: 'Andrew S. Tanenbaum, David J. Wetherall',
        publisher: 'Pearson',
        year_published: 2021,
        isbn: '978-0132126953',
        copies_total: 8,
        copies_avail: 5,
        category: 'Computer Networks'
      },
      {
        book_id: 11,
        title: 'Introduction to the Theory of Computation',
        author: 'Michael Sipser',
        publisher: 'Cengage Learning',
        year_published: 2012,
        isbn: '978-1133187790',
        copies_total: 6,
        copies_avail: 3,
        category: 'Theory of Computation'
      },
      {
        book_id: 12,
        title: 'Learning SQL',
        author: 'Alan Beaulieu',
        publisher: "O'Reilly Media",
        year_published: 2020,
        isbn: '978-1492057611',
        copies_total: 9,
        copies_avail: 6,
        category: 'Database Management'
      },
      {
        book_id: 13,
        title: 'MongoDB: The Definitive Guide',
        author: 'Kristina Chodorow, Shannon Bradshaw',
        publisher: "O'Reilly Media",
        year_published: 2019,
        isbn: '978-1491954461',
        copies_total: 5,
        copies_avail: 2,
        category: 'Database Management'
      },
      {
        book_id: 14,
        title: 'Computer Organization and Design',
        author: 'David A. Patterson, John L. Hennessy',
        publisher: 'Morgan Kaufmann',
        year_published: 2020,
        isbn: '978-0128122754',
        copies_total: 7,
        copies_avail: 4,
        category: 'Computer Architecture'
      },
      {
        book_id: 15,
        title: 'Introduction to Algorithms',
        author: 'Thomas H. Cormen, Charles E. Leiserson',
        publisher: 'MIT Press',
        year_published: 2009,
        isbn: '978-0262033848',
        copies_total: 10,
        copies_avail: 7,
        category: 'Algorithms'
      },
      {
        book_id: 16,
        title: 'Software Engineering: A Practitioner\'s Approach',
        author: 'Roger S. Pressman, Bruce R. Maxim',
        publisher: 'McGraw-Hill',
        year_published: 2019,
        isbn: '978-1259872976',
        copies_total: 6,
        copies_avail: 4,
        category: 'Software Engineering'
      },
      {
        book_id: 17,
        title: 'Cybersecurity Essentials',
        author: 'Charles J. Brooks, Christopher Grow',
        publisher: 'Wiley',
        year_published: 2018,
        isbn: '978-1119362395',
        copies_total: 8,
        copies_avail: 5,
        category: 'Cybersecurity'
      },
      {
        book_id: 18,
        title: 'React: Up & Running',
        author: 'Stoyan Stefanov',
        publisher: "O'Reilly Media",
        year_published: 2021,
        isbn: '978-1492051718',
        copies_total: 5,
        copies_avail: 3,
        category: 'Web Development'
      }
    ];

    const sampleStudents: Student[] = [
      {
        student_id: 1,
        name: 'Sam Kumar',
        email: 'sam.kumar@university.edu',
        course: 'Computer Science',
        year: 3,
        phone: '+91-9876543210',
        address: '123 Tech Park, Hyderabad, Telangana 500032'
      },
      {
        student_id: 2,
        name: 'Bhargav Reddy',
        email: 'bhargav.reddy@university.edu',
        course: 'Information Technology',
        year: 2,
        phone: '+91-9876543211',
        address: '456 Silicon Valley, Bangalore, Karnataka 560001'
      },
      {
        student_id: 3,
        name: 'Navaneeth Sharma',
        email: 'navaneeth.sharma@university.edu',
        course: 'Computer Science',
        year: 4,
        phone: '+91-9876543212',
        address: '789 Cyber City, Pune, Maharashtra 411001'
      },
      {
        student_id: 4,
        name: 'Loki Varma',
        email: 'loki.varma@university.edu',
        course: 'Software Engineering',
        year: 3,
        phone: '+91-9876543213',
        address: '321 Innovation Hub, Chennai, Tamil Nadu 600001'
      },
      {
        student_id: 5,
        name: 'Vishnu Prasad',
        email: 'vishnu.prasad@university.edu',
        course: 'Computer Science',
        year: 2,
        phone: '+91-9876543214',
        address: '654 Digital Plaza, Kochi, Kerala 682001'
      },
      {
        student_id: 6,
        name: 'Ganesh Patel',
        email: 'ganesh.patel@university.edu',
        course: 'Information Technology',
        year: 4,
        phone: '+91-9876543215',
        address: '987 Tech Tower, Ahmedabad, Gujarat 380001'
      },
      {
        student_id: 7,
        name: 'Vamsi Krishna',
        email: 'vamsi.krishna@university.edu',
        course: 'Computer Science',
        year: 3,
        phone: '+91-9876543216',
        address: '147 IT Corridor, Visakhapatnam, Andhra Pradesh 530001'
      },
      {
        student_id: 8,
        name: 'Shalem Joseph',
        email: 'shalem.joseph@university.edu',
        course: 'Cybersecurity',
        year: 2,
        phone: '+91-9876543217',
        address: '258 Security Square, Mumbai, Maharashtra 400001'
      },
      {
        student_id: 9,
        name: 'Bindu Lakshmi',
        email: 'bindu.lakshmi@university.edu',
        course: 'Computer Science',
        year: 4,
        phone: '+91-9876543218',
        address: '369 Women Tech Park, Mysore, Karnataka 570001'
      },
      {
        student_id: 10,
        name: 'Teju Sree',
        email: 'teju.sree@university.edu',
        course: 'Information Technology',
        year: 3,
        phone: '+91-9876543219',
        address: '741 Innovation Center, Warangal, Telangana 506001'
      },
      {
        student_id: 11,
        name: 'Sreya Nair',
        email: 'sreya.nair@university.edu',
        course: 'Software Engineering',
        year: 2,
        phone: '+91-9876543220',
        address: '852 Tech Valley, Thiruvananthapuram, Kerala 695001'
      },
      {
        student_id: 12,
        name: 'Rohi Gupta',
        email: 'rohi.gupta@university.edu',
        course: 'Computer Science',
        year: 4,
        phone: '+91-9876543221',
        address: '963 Digital Hub, Jaipur, Rajasthan 302001'
      },
      {
        student_id: 13,
        name: 'Likki Rao',
        email: 'likki.rao@university.edu',
        course: 'Information Technology',
        year: 3,
        phone: '+91-9876543222',
        address: '159 Cyber Park, Bhubaneswar, Odisha 751001'
      },
      {
        student_id: 14,
        name: 'Sharmila Devi',
        email: 'sharmila.devi@university.edu',
        course: 'Computer Science',
        year: 2,
        phone: '+91-9876543223',
        address: '357 Tech Campus, Coimbatore, Tamil Nadu 641001'
      }
    ];

    const sampleIssueLogs: IssueLog[] = [
      {
        issue_id: 1,
        book_id: 3,
        student_id: 1,
        book_title: 'Python Crash Course',
        student_name: 'Sam Kumar',
        issue_date: '2024-01-15',
        due_date: '2024-01-29',
        status: 'issued'
      },
      {
        issue_id: 2,
        book_id: 4,
        student_id: 2,
        book_title: 'Effective Java',
        student_name: 'Bhargav Reddy',
        issue_date: '2024-01-10',
        due_date: '2024-01-24',
        status: 'issued'
      },
      {
        issue_id: 3,
        book_id: 6,
        student_id: 3,
        book_title: 'JavaScript: The Definitive Guide',
        student_name: 'Navaneeth Sharma',
        issue_date: '2024-01-08',
        due_date: '2024-01-22',
        status: 'issued'
      },
      {
        issue_id: 4,
        book_id: 8,
        student_id: 4,
        book_title: 'Operating System Concepts',
        student_name: 'Loki Varma',
        issue_date: '2024-01-05',
        due_date: '2024-01-19',
        status: 'overdue',
        fine_amount: 15
      },
      {
        issue_id: 5,
        book_id: 9,
        student_id: 5,
        book_title: 'Database System Concepts',
        student_name: 'Vishnu Prasad',
        issue_date: '2024-01-12',
        due_date: '2024-01-26',
        status: 'issued'
      },
      {
        issue_id: 6,
        book_id: 13,
        student_id: 6,
        book_title: 'MongoDB: The Definitive Guide',
        student_name: 'Ganesh Patel',
        issue_date: '2024-01-01',
        due_date: '2024-01-15',
        status: 'overdue',
        fine_amount: 20
      },
      {
        issue_id: 7,
        book_id: 5,
        student_id: 7,
        book_title: 'HTML and CSS: Design and Build Websites',
        student_name: 'Vamsi Krishna',
        issue_date: '2024-01-14',
        due_date: '2024-01-28',
        status: 'issued'
      },
      {
        issue_id: 8,
        book_id: 17,
        student_id: 8,
        book_title: 'Cybersecurity Essentials',
        student_name: 'Shalem Joseph',
        issue_date: '2024-01-11',
        due_date: '2024-01-25',
        status: 'issued'
      },
      {
        issue_id: 9,
        book_id: 15,
        student_id: 9,
        book_title: 'Introduction to Algorithms',
        student_name: 'Bindu Lakshmi',
        issue_date: '2024-01-09',
        due_date: '2024-01-23',
        status: 'issued'
      },
      {
        issue_id: 10,
        book_id: 12,
        student_id: 10,
        book_title: 'Learning SQL',
        student_name: 'Teju Sree',
        issue_date: '2024-01-13',
        due_date: '2024-01-27',
        status: 'issued'
      },
      {
        issue_id: 11,
        book_id: 2,
        student_id: 11,
        book_title: 'C++ Primer',
        student_name: 'Sreya Nair',
        issue_date: '2023-12-28',
        due_date: '2024-01-11',
        return_date: '2024-01-10',
        status: 'returned'
      },
      {
        issue_id: 12,
        book_id: 1,
        student_id: 12,
        book_title: 'The C Programming Language',
        student_name: 'Rohi Gupta',
        issue_date: '2024-01-07',
        due_date: '2024-01-21',
        status: 'issued'
      },
      {
        issue_id: 13,
        book_id: 18,
        student_id: 13,
        book_title: 'React: Up & Running',
        student_name: 'Likki Rao',
        issue_date: '2024-01-06',
        due_date: '2024-01-20',
        status: 'issued'
      },
      {
        issue_id: 14,
        book_id: 10,
        student_id: 14,
        book_title: 'Computer Networks',
        student_name: 'Sharmila Devi',
        issue_date: '2023-12-30',
        due_date: '2024-01-13',
        status: 'overdue',
        fine_amount: 25
      }
    ];

    setBooks(sampleBooks);
    setStudents(sampleStudents);
    setIssueLogs(sampleIssueLogs);
  };

  const handleLogin = (credentials: { username: string; password: string }) => {
    // Simple authentication - in real app, this would be API call
    if (credentials.username === 'admin' && credentials.password === 'admin123') {
      setIsAuthenticated(true);
      localStorage.setItem('isAuthenticated', 'true');
      initializeData();
      return true;
    }
    return false;
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('isAuthenticated');
    setCurrentPage('dashboard');
  };

  const addBook = (book: Omit<Book, 'book_id'>) => {
    const newBook: Book = {
      ...book,
      book_id: Math.max(...books.map(b => b.book_id), 0) + 1,
      copies_avail: book.copies_total
    };
    setBooks([newBook, ...books]);
  };

  const addStudent = (student: Omit<Student, 'student_id'>) => {
    const newStudent: Student = {
      ...student,
      student_id: Math.max(...students.map(s => s.student_id), 0) + 1
    };
    setStudents([newStudent, ...students]);
  };

  const issueBook = (bookId: number, studentId: number) => {
    const book = books.find(b => b.book_id === bookId);
    const student = students.find(s => s.student_id === studentId);
    
    if (!book || !student || book.copies_avail <= 0) return false;

    const issueDate = new Date();
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 14);

    const newIssue: IssueLog = {
      issue_id: Math.max(...issueLogs.map(i => i.issue_id), 0) + 1,
      book_id: bookId,
      student_id: studentId,
      book_title: book.title,
      student_name: student.name,
      issue_date: issueDate.toISOString().split('T')[0],
      due_date: dueDate.toISOString().split('T')[0],
      status: 'issued'
    };

    setIssueLogs([newIssue, ...issueLogs]);
    setBooks(books.map(b => 
      b.book_id === bookId 
        ? { ...b, copies_avail: b.copies_avail - 1 }
        : b
    ));

    return true;
  };

  const returnBook = (issueId: number) => {
    const returnDate = new Date().toISOString().split('T')[0];
    const issue = issueLogs.find(i => i.issue_id === issueId);
    
    if (!issue) return false;

    setIssueLogs(issueLogs.map(log => 
      log.issue_id === issueId 
        ? { ...log, return_date: returnDate, status: 'returned' as const }
        : log
    ));

    setBooks(books.map(b => 
      b.book_id === issue.book_id 
        ? { ...b, copies_avail: b.copies_avail + 1 }
        : b
    ));

    return true;
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return (
          <Dashboard 
            books={books}
            students={students}
            issueLogs={issueLogs}
            onPageChange={setCurrentPage}
            onAddBook={addBook}
            onAddStudent={addStudent}
            onIssueBook={issueBook}
          />
        );
      case 'books':
        return <BookManagement books={books} onAddBook={addBook} />;
      case 'students':
        return <StudentManagement students={students} onAddStudent={addStudent} />;
      case 'issues':
        return (
          <IssueReturn 
            books={books}
            students={students}
            issueLogs={issueLogs}
            onIssueBook={issueBook}
            onReturnBook={returnBook}
          />
        );
      case 'reports':
        return <Reports books={books} students={students} issueLogs={issueLogs} />;
      default:
        return (
          <Dashboard 
            books={books}
            students={students}
            issueLogs={issueLogs}
            onPageChange={setCurrentPage}
            onAddBook={addBook}
            onAddStudent={addStudent}
            onIssueBook={issueBook}
          />
        );
    }
  };

  return (
    <Layout 
      currentPage={currentPage} 
      onPageChange={setCurrentPage}
      onLogout={handleLogout}
    >
      {renderCurrentPage()}
    </Layout>
  );
}

export default App;